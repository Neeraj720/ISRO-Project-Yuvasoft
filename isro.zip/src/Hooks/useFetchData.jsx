import React, { useEffect, useState } from 'react'
import Api from '../Service/Api'

function useFetchData(endPoint) {
const [data,setData] = useState([])
const [error,setError] = useState(null)
const[loading,setLoading] = useState(false)
useEffect(()=>{
    const fetchData = async () => {
        setLoading(true);
        try {
            const response = await Api.get(`${endPoint}`);
            if(endPoint == "/api/spacecrafts"){
            setData(response.data.spacecrafts);
            }
            else if(endPoint == "/api/launchers"){
                // console.log(response.data);  
                setData(response.data.launchers)
            }
            else if(endPoint == '/api/customer_satellites')
            {
                setData(response.data.customer_satellites)
            }
            else if(endPoint == "/api/centres"){
                console.log(response.data.centres)
                setData(response.data.centres)
            }
        } catch (err) {
            setError(err);
        } finally {
            setLoading(false);
        }
    };
    fetchData();
},[endPoint])
  return {data,error,loading}
}

export default useFetchData