import React from 'react'

function Home() {
  return (
    <>
    <div className='d-flex align-items-center justify-content-center vh-100'>
        <h1 className='text-danger'>Wellcome To The ISRO Deshbord</h1>
    </div>
    </>
  )
}

export default Home