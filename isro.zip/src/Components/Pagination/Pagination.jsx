import React from 'react';

const Pagination = ({ totalPages, currentPage, onPageChange }) => {
  const handleNext = () => {
    if (currentPage < totalPages) {
      onPageChange(currentPage + 1);
    }
  };
  const handlePrevious = () => {
    if (currentPage > 1) {
      onPageChange(currentPage - 1);
    }
  };
  return (
    <div className="container mb-3">
      <div className="d-flex align-items-center justify-content-center">
        <button
          className='btn btn-secondary me-3'
          onClick={handlePrevious}
          disabled={currentPage === 1}
        >
          Previous
        </button>

        <div>
          {Array.from({ length: totalPages }, (_, index) => (
            <button
              key={index + 1}
              className={`btn me-3 ${currentPage === index + 1 ? 'btn-primary' : 'btn-outline-primary'}`}
              onClick={() => onPageChange(index + 1)}
            >
              {index + 1}
            </button>
          ))}
        </div>
        <button
          className='btn btn-secondary'
          onClick={handleNext}
          disabled={currentPage === totalPages}
        >
          Next
        </button>
      </div>
    </div>
  );
};

export default Pagination;


